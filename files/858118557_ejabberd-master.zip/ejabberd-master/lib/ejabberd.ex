defmodule Ejabberd do
end
